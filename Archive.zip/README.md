# Cross browser add-on better experience on gomovies.tube
A cross browser add-on to remove ads & banners from gomovies movie player. Its Beta version.. More functionalities to come soon.

# Firefox listing link
https://addons.mozilla.org/en-US/firefox/user/ram_vaishnav/

# Description
* This add-on automatically hides Ad banner from gomovies player.
* This add-on also skips ad videos.
* Enjoy seamless experience from this very light weight add-on.
* This addon is completely safe to use as this addon removes ads from banner by double confirming that the add-on is not hiding any useful content accidentally.
* This is an open source project, find the code on https://github.com/gurumukhi/.

Special Feature
* This add-on supports verbose/debug mode on option page. This mode enables verbose logging in the browser console.

Support:
* Kindly feel free to open an issue on https://github.com/gurumukhi/ for any support.